import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Send, Loader2, CheckCircle2, XCircle, ShieldCheck, Flag, Info } from "lucide-react";
import ReportIssueDialog from "@/components/ReportIssueDialog";

export default function Submit() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [courseraLink, setCourseraLink] = useState("");
  const [linkedinLink, setLinkedinLink] = useState("");
  const [projectLink, setProjectLink] = useState("");
  const [verifying, setVerifying] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [verified, setVerified] = useState(false);
  const [verifyError, setVerifyError] = useState("");
  const [verifiedSubmissionId, setVerifiedSubmissionId] = useState<string | null>(null);
  const [reportOpen, setReportOpen] = useState(false);
  const [helpModal, setHelpModal] = useState<{ title: string; image: string } | null>(null);
  const [showLinkedInTip, setShowLinkedInTip] = useState(false);
  const [linkedinFocused, setLinkedinFocused] = useState(false);
  // const linksValid =
  //   courseraLink.includes("coursera.org") &&
  //   linkedinLink.includes("linkedin.com") &&
  //   projectLink.includes("coursera.org");
  const linksValid =
    courseraLink.includes("coursera.org/account/accomplishments/verify/") &&
    linkedinLink.includes("linkedin.com") &&
    projectLink.includes("coursera.org/projects/");

  const handleVerify = async () => {
    if (!user || !profile) return;

    if (!courseraLink.includes("coursera.org")) {
      toast.error("Please enter a valid Coursera certificate link");
      return;
    }
    if (!linkedinLink.includes("linkedin.com")) {
      toast.error("Please enter a valid LinkedIn link");
      return;
    }
    if (!projectLink.includes("coursera.org/projects/")) {
      toast.error("Please enter a valid Coursera project link (coursera.org/projects/...)");
      return;
    }

    setVerifying(true);
    setVerifyError("");
    setVerified(false);
    setVerifiedSubmissionId(null);

    try {
      const { data: existing } = await supabase
        .from("submissions")
        .select("id")
        .eq("user_id", user.id)
        .eq("coursera_link", courseraLink.trim())
        .eq("status", "correct")
        .limit(1);

      if (existing && existing.length > 0) {
        setVerifyError("This course has already been submitted and verified.");
        setVerifying(false);
        return;
      }

      const { data: submission, error } = await supabase
        .from("submissions")
        .insert({
          user_id: user.id,
          college_id: profile.college_id,
          coursera_link: courseraLink.trim(),
          linkedin_link: linkedinLink.trim(),
          project_link: projectLink.trim(),
        } as any)
        .select()
        .single();

      if (error) throw error;

      const { data: result, error: fnError } = await supabase.functions.invoke(
        "verify-submission",
        { body: { submission_id: submission.id } }
      );

      if (fnError) throw fnError;

      if (result?.status === "correct") {
        setVerified(true);
        setVerifiedSubmissionId(submission.id);
        setVerifyError("");
      } else {
        await supabase.from("submissions").delete().eq("id", submission.id);
        setVerifyError(
          result?.error_message || "Verification failed — name on certificate/LinkedIn does not match your profile, or the certificate could not be read. Please check your links and try again."
        );
      }
    } catch (err: any) {
      setVerifyError(err.message || "Verification failed");
    } finally {
      setVerifying(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!verified || !verifiedSubmissionId) return;

    setSubmitting(true);
    try {
      toast.success("Submission confirmed!");
      setCourseraLink("");
      setLinkedinLink("");
      setProjectLink("");
      setVerified(false);
      setVerifiedSubmissionId(null);
      navigate("/my-submissions");
    } finally {
      setSubmitting(false);
    }
  };

  const handleLinkChange = (setter: (v: string) => void, value: string) => {
    setter(value);
    setVerified(false);
    setVerifyError("");
    setVerifiedSubmissionId(null);
  };

  return (
    <div className="container max-w-lg py-10">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Send className="h-5 w-5" /> Submit Project
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="coursera">Coursera Certificate Link</Label>
              <div className="relative">
                <Input
                  id="coursera"
                  value={courseraLink}
                  onChange={(e) => handleLinkChange(setCourseraLink, e.target.value)}
                  placeholder="https://www.coursera.org/account/accomplishments/..."
                  required
                  disabled={verified}
                  className="pr-9"
                />
                <button
                  type="button"
                  onClick={() => setHelpModal({ title: "Where to find your Coursera Certificate Link", image: "/certificate-help.png" })}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  <Info className="h-4 w-4" />
                </button>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="project">Coursera Project Link</Label>
              <div className="relative">
                <Input
                  id="project"
                  value={projectLink}
                  onChange={(e) => handleLinkChange(setProjectLink, e.target.value)}
                  placeholder="https://www.coursera.org/projects/your-project-name"
                  required
                  disabled={verified}
                  className="pr-9"
                />
                <button
                  type="button"
                  onClick={() => setHelpModal({ title: "Where to find your Coursera Project Link", image: "/project-help.png" })}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  <Info className="h-4 w-4" />
                </button>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="linkedin">LinkedIn Post Link</Label>
              <div className="relative">
                <Input
                  id="linkedin"
                  value={linkedinLink}
                  onChange={(e) => handleLinkChange(setLinkedinLink, e.target.value)}
                  onFocus={() => setLinkedinFocused(true)}
                  onBlur={() => setLinkedinFocused(false)}
                  placeholder="https://www.linkedin.com/posts/..."
                  required
                  disabled={verified}
                  className="pr-9"
                />
                <button
                  type="button"
                  onClick={() => setHelpModal({ title: "Where to find your LinkedIn Post Link", image: "/linkedin-help.png" })}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  <Info className="h-4 w-4" />
                </button>
                {/* Tooltip on focus */}
                {/* {linkedinFocused && (
                  <div className="absolute left-0 top-full mt-1.5 z-10 w-full rounded-md border bg-popover px-3 py-2 text-xs text-popover-foreground shadow-md">
                    ⚠️ Mention the course name in the <span className="font-semibold">first line</span> of your post (within 200 characters) for automatic verification.
                  </div>
                )} */}
              </div>
              {/* Collapsible how-to section */}
              <button
                type="button"
                onClick={() => setShowLinkedInTip((v) => !v)}
                className="flex items-center gap-1 text-xs text-primary hover:underline focus:outline-none"
              >
                <span>{showLinkedInTip ? "▾" : "▸"}</span>
                How should I write my LinkedIn post?
              </button>
              {showLinkedInTip && (
                <div className="rounded-md border bg-muted/40 px-3 py-2.5 text-xs space-y-1.5 text-muted-foreground">
                  <p className="font-medium text-foreground">For automatic verification, your post must:</p>
                  <p>✅ Mention the <span className="font-medium text-foreground">exact course name in the first line</span> (before any line break)</p>
                  <p>✅ Be a <span className="font-medium text-foreground">public post</span> (not friends-only)</p>
                  <p className="italic border-l-2 border-primary/40 pl-2">
                    Example: "Just completed '<strong>Build a CI/CD Pipeline with Docker</strong>' on Coursera! 🎉 Check it out 👇 #Coursera"
                  </p>
                  <p>❌ Do <span className="font-medium text-foreground">not</span> mention the course name only in comments or deep in the post body</p>
                </div>
              )}
            </div>

            {verifyError && (
              <Alert variant="destructive">
                <XCircle className="h-4 w-4" />
                <AlertDescription>{verifyError}</AlertDescription>
              </Alert>
            )}

            {verifyError && (
              <Button
                type="button"
                variant="outline"
                className="w-full gap-2"
                onClick={() => setReportOpen(true)}
              >
                <Flag className="h-4 w-4" /> Report an Issue
              </Button>
            )}

            {verified && (
              <Alert>
                <CheckCircle2 className="h-4 w-4 text-primary" />
                <AlertDescription className="font-medium">
                  Verification passed! You can now submit.
                </AlertDescription>
              </Alert>
            )}

            {!verified ? (
              <Button
                type="button"
                className="w-full"
                disabled={verifying || !linksValid}
                onClick={handleVerify}
              >
                {verifying ? (
                  <><Loader2 className="h-4 w-4 animate-spin" /> Verifying...</>
                ) : (
                  <><ShieldCheck className="h-4 w-4" /> Verify</>
                )}
              </Button>
            ) : (
              <Button type="submit" className="w-full" disabled={submitting}>
                {submitting ? (
                  <><Loader2 className="h-4 w-4 animate-spin" /> Submitting...</>
                ) : (
                  <><Send className="h-4 w-4" /> Submit</>
                )}
              </Button>
            )}
          </form>
        </CardContent>
      </Card>

      <ReportIssueDialog
        open={reportOpen}
        onOpenChange={setReportOpen}
        courseraLink={courseraLink}
        linkedinLink={linkedinLink}
        projectLink={projectLink}
      />

      <Dialog open={!!helpModal} onOpenChange={(open) => !open && setHelpModal(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{helpModal?.title}</DialogTitle>
          </DialogHeader>
          <img
            src={helpModal?.image}
            alt={helpModal?.title}
            className="w-full rounded-md border aspect-video object-cover bg-muted"
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}

